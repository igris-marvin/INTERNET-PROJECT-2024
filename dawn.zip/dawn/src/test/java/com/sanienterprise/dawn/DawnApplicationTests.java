package com.sanienterprise.dawn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawnApplicationTests {

	@Test
	void contextLoads() {
	}

}
