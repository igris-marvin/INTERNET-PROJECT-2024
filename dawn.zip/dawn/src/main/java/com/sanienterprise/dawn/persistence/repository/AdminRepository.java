package com.sanienterprise.dawn.persistence.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepository extends PatronRepository {
    
}
