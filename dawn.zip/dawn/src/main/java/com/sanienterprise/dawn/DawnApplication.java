package com.sanienterprise.dawn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawnApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawnApplication.class, args);
	}

}
