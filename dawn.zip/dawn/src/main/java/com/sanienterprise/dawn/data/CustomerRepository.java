package com.sanienterprise.dawn.data;

import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends UserRepository {
    
}
