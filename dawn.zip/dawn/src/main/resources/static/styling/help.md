# this folder is for CSS files

# even if we use bootstrap, we might need to add additional styling which the bootstrap might not provide, this is where we create out own CSS for specific stylings, then we store them in this folder